__version__ = "1.0.0"
from ._widget import UniSPACwidget

__all__ = (
    "UniSPACwidget"
)
